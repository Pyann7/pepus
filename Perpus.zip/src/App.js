import React from "react";
import LibraryHeroSection from "./components/LibraryHeroSection";

function App() {
  return (
    <div className="App">
      <LibraryHeroSection />
      {/* Tambahkan komponen lain di sini seiring pengembangan aplikasi */}
    </div>
  );
}

export default App;
