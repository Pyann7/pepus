module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      // Tambahkan kustomisasi tema di sini jika diperlukan
    },
  },
  plugins: [],
};
